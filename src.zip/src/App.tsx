"use client"

import type React from "react"

import "./App.css"
import { useState, useRef } from "react"
import pinktraingle from "./assets/pink-triangle.png"
import pinksquare from "./assets/pink-square.png"
import pinkcircle from "./assets/pink-circle.png"
import squidGameBg from "./assets/squid-game-14.jpg"

function App() {
  const [clicked, setClicked] = useState(false)
  const aboutRef = useRef<HTMLDivElement>(null)
  const timelineRef = useRef<HTMLDivElement>(null)

  const scrollToSection = (ref: React.RefObject<HTMLDivElement>) => {
    if (ref.current) {
      ref.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <>
      <div className="relative w-full h-screen bg-black flex justify-center items-center flex-col">
        <div className="text-7xl text-fuchsia-400 absolute top-5 font-mono">AERAVAT</div>
        <div
          className="absolute md:w-40 md:h-40 w-20 h-20 rounded-full border-fuchsia-400 md:border-4 border-2 text-fuchsia-400 top-1/2 translate-y-[90px] md:translate-y-[180px] bottom-50 flex justify-center items-center shadow-[0px_0px_20px_rgb(255,100,200)] transition-all duration-300 ease-in-out cursor-pointer hover:bg-fuchsia-400/20"
          style={{
            opacity: clicked ? 1 : 0,
            transform: clicked ? "translate(0px, 0px)" : "translate(0px,-200px)",
          }}
          onClick={() => scrollToSection(aboutRef)}
        >
          ABOUT
        </div>
        <div
          className="absolute md:w-40 md:h-40 w-20 h-20 rounded-full border-fuchsia-400 md:border-4 border-2 text-fuchsia-400 top-1/2 translate-y-[-100px] translate-x-[-115px] md:translate-y-[-200px] md:translate-x-[-230px] bottom-50 flex justify-center items-center shadow-[0px_0px_20px_rgb(255,100,200)] transition-all duration-300 ease-in-out cursor-pointer hover:bg-fuchsia-400/20"
          style={{
            opacity: clicked ? 1 : 0,
            transform: clicked ? "translate(0px, 0px)" : "translate(200px, 80px)",
          }}
          onClick={() => scrollToSection(timelineRef)}
        >
          TIMELINE
        </div>
        <div
          className="absolute md:w-40 md:h-40 w-20 h-20 rounded-full border-fuchsia-400 md:border-4 border-2 text-fuchsia-400 top-1/2 translate-y-[-100px] translate-x-[115px] md:translate-y-[-200px] md:translate-x-[230px] bottom-50 flex justify-center items-center shadow-[0px_0px_20px_rgb(255,100,200)] transition-all duration-300 ease-in-out cursor-pointer hover:bg-fuchsia-400/20"
          style={{
            opacity: clicked ? 1 : 0,
            transform: clicked ? "translate(0px, 0px)" : "translate(-200px,80px)",
          }}
        >
          CONTACT
        </div>
        <div
          className="relative md:w-80 md:h-80 w-40 h-40 rounded-full md:border-4 border-2 border-fuchsia-400 flex flex-col shadow-[0px_0px_20px_rgb(255,100,200)] rotate cursor-pointer transition-colors duration-300 ease-in-out"
          style={{ backgroundColor: clicked ? "rgb(250,50,250)" : "black" }}
          onClick={() => {
            setClicked(!clicked)
          }}
        >
          <div className="md:w-20 md:h-20 w-10 h-10 bg-black absolute md:top-15 md:left-6 top-7 left-3 rounded-full border-2 border-fuchsia-400 flex justify-center items-center">
            <img className="md:w-14 md:h-12 mb-2 w-7 h-6" src={pinktraingle || "/placeholder.svg"}></img>
          </div>
          <div className="md:w-20 md:h-20 w-10 h-10 bg-black absolute md:top-15 md:right-6 top-7 right-3 rounded-full border-2 border-fuchsia-400 flex justify-center items-center">
            <img className="md:w-14 md:h-14 w-7 h-7" src={pinksquare || "/placeholder.svg"}></img>
          </div>
          <div className="md:w-20 md:h-20 w-10 h-10 bg-black absolute md:bottom-2 left-1/2 -translate-x-1/2 bottom-1 rounded-full border-2 border-fuchsia-400 flex justify-center items-center">
            <img className="md:w-14 md:h-14 w-7 h-7" src={pinkcircle || "/placeholder.svg"}></img>
          </div>
          <div className="md:w-30 md:h-30 w-15 h-15 bg-black absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-fuchsia-400 justify-center items-center"></div>
        </div>
      </div>

      <div
        ref={aboutRef}
        className="relative w-full h-screen bg-black flex flex-col items-center justify-center overflow-hidden"
      >
        <div
          className="absolute top-0 left-0 w-full h-full z-0 bg-cover bg-center bg-no-repeat opacity-40"
          style={{ backgroundImage: `url(${squidGameBg})` }}
        ></div>

        <div className="absolute top-0 left-0 w-full h-full bg-black opacity-50 z-0"></div>

        <div className="absolute top-8 left-0 w-full flex justify-center z-10">
          <div className="squid-title text-5xl md:text-7xl text-white font-bold tracking-widest">ABOUT</div>
        </div>

        <div className="w-full max-w-6xl flex flex-col md:flex-row items-center justify-center px-4 md:px-10 z-10 mt-16 md:mt-0">
          <div className="w-full md:w-1/2 max-w-md mb-8 md:mb-0 md:mr-8 transform transition-all duration-500 hover:scale-105">
            <div className="relative bg-transparent bg-opacity-40 backdrop-blur-[2px] rounded-lg overflow-hidden border-2 border-[#ff3d6f] h-[400px] flex flex-col">
              <div className="pt-20 pb-8 px-6 flex flex-col flex-grow">
                <h2 className="text-white text-3xl font-bold mb-4 mt-2">ABOUT AERAVAT</h2>
                <div className="bg-[#ff3d6f] h-0.5 w-full mb-6"></div>
                <p className="text-white text-lg flex-grow">
                  Aeravat is a cutting-edge technology collective that operates like the ultimate game. We follow strict
                  rules of excellence and innovation, eliminating obstacles that stand in our way.
                </p>

                <div className="mt-auto flex justify-between items-center">
                  <div className="squid-button px-6 py-2 bg-squid-pink text-white font-bold rounded cursor-pointer hover:bg-white hover:text-squid-pink transition-colors">
                    LEARN MORE
                  </div>
                  <div className="w-12 h-12 bg-squid-pink rounded-full flex items-center justify-center">
                    <div className="w-6 h-6 bg-white rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="w-full md:w-1/2 max-w-md transform transition-all duration-500 hover:scale-105">
            <div className="relative bg-transparent bg-opacity-40 backdrop-blur-[2px] rounded-lg overflow-hidden border-2 border-[#1f9e62] h-[400px] flex flex-col">
              <div className="pt-20 pb-8 px-6 flex flex-col flex-grow">
                <h2 className="text-white text-3xl font-bold mb-4 mt-2">DOMAINS</h2>
                <div className="bg-[#1f9e62] h-0.5 w-full mb-6"></div>

                <div className="grid grid-cols-2 gap-4 text-white">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-[#1f9e62] rounded-full mr-2"></div>
                    <span>AI in FinTech</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-[#1f9e62] rounded-full mr-2"></div>
                    <span>AI in HealthTech</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-[#1f9e62] rounded-full mr-2"></div>
                    <span>GenAI</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-[#1f9e62] rounded-full mr-2"></div>
                    <span>AI for Social Cause</span>
                  </div>
                </div>

                <div className="mt-auto flex justify-between items-center">
                  <div className="squid-button px-6 py-2 bg-squid-green text-white font-bold rounded cursor-pointer hover:bg-white hover:text-squid-green transition-colors">
                    REGISTER
                  </div>
                  <div className="w-12 h-12 bg-[#1f9e62] flex items-center justify-center border-2">
                    <div className="w-8 h-8 bg-white square"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div ref={timelineRef} className="relative w-full h-[200vh] bg-black justify-center flex">
        <div className="md:w-3/7 w-1/2">
          <div className="md:mt-22 mt-17 h-40 md:mr-10 mr-4 md:w-96 w-40 float-right border-2 border-fuchsia-500 glow rounded-xl"></div>
          <div className="md:mt-104 mt-88 h-40 md:mr-10 mr-4 md:w-96 w-40 float-right border-2 border-fuchsia-500 glow rounded-xl"></div>
        </div>
        <div className="relative h-full bg-black justify-center flex flex-col">
          <img className="m-auto md:w-14 md:h-14 w-7 h-7 rotate" src={pinksquare || "/placeholder.svg"}></img>
          <div className="m-auto w-1 bg-fuchsia-500 mt-5 mb-5 h-50 rounded-full glow"></div>
          <img className="m-auto md:w-14 md:h-14 w-7 h-7 rotate" src={pinktraingle || "/placeholder.svg"}></img>
          <div className="m-auto w-1 bg-fuchsia-500 mt-5 mb-5 h-50 rounded-full glow"></div>
          <img className="m-auto md:w-14 md:h-14 w-7 h-7 rotate" src={pinksquare || "/placeholder.svg"}></img>
          <div className="m-auto w-1 bg-fuchsia-500 mt-5 mb-5 h-50 rounded-full glow"></div>
          <img className="m-auto md:w-14 md:h-14 w-7 h-7 rotate" src={pinktraingle || "/placeholder.svg"}></img>
          <div className="m-auto w-1 bg-fuchsia-500 mt-5 mb-5 h-50 rounded-full glow"></div>
          <img className="m-auto mb-10 md:w-14 md:h-14 w-7 h-7 rotate" src={pinksquare || "/placeholder.svg"}></img>
        </div>
        <div className="md:w-3/7 w-1/2">
          <div className="mt-80 md:mt-94 h-40 md:w-96 md:ml-10 ml-4 w-40 float-left border-2 border-fuchsia-500 glow rounded-xl"></div>
          <div className="md:mt-104 mt-88 h-40 md:ml-10 ml-4 md:w-96 w-40 float-left border-2 border-fuchsia-500 glow rounded-xl"></div>
        </div>
      </div>
    </>
  )
}

export default App

